// Code for swapping two numbers
using System;
public class Exercise5
{
       public static void Main(string[] args)
         {
            int number1, number2, temp;
            number1 = 3;
            number2 = 9;
            temp = number1;
            number1 = number2;
            number2 = temp;
            Console.Write("\nAfter Swapping : ");
            Console.Write("\nFirst Number : "+number1);
            Console.Write("\nSecond Number : "+number2);
            Console.Read();
        }
}